#!/bin/sh

###1. unzip supersu zip file
unzip -d SuperSU SuperSU.zip 
###2. adb shell mkdir /tmp/supersu & push into phone
adb wait-for-device
adb root
adb remount
adb wait-for-device

adb shell mkdir -p /data/tmp/supersu
adb push SuperSU /data/tmp/supersu

###3. push update-binary.sh & most tools
adb push update-binary.sh /data/
adb push blkparse /data/
adb push blktrace /data/
adb push most /data/
adb push filter.sh /data/

###4. exec update-binary.sh
adb shell /data/update-binary.sh

adb reboot
adb wait-for-device
adb shell setenforce 0
